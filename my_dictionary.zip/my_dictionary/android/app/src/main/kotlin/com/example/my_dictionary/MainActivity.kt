package com.example.my_dictionary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
